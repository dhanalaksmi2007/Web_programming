# ShareShelf — XAMPP / MySQL edition

This edition replaces the original Oracle database connection with MySQL, which is included with XAMPP. The React/Vite frontend and Express API remain the same.

## Quick start (Windows)

1. Install/open XAMPP Control Panel and click **Start** beside **MySQL**. Apache is not required for the API, but can be started if you want phpMyAdmin.
2. Open `http://localhost/phpmyadmin`.
3. Choose **Import**, select `database/schema.sql`, and click **Import** / **Go**. Alternatively, open the SQL tab and paste/run that file. It creates the `shareshelf` database and both tables.
4. In `server`, copy `.env.example` to a file named `.env`. Defaults are for a standard XAMPP setup (`root`, blank password). If you configured a MySQL root password, put it in `DB_PASSWORD`.
5. Open a terminal in the project folder and run:

   Terminal 1:
   ```powershell
   cd server
   npm install
   npm run dev
   ```
   Wait for `ShareShelf API running at http://localhost:5000` and `MySQL connected successfully`.

   Terminal 2:
   ```powershell
   cd client
   npm install
   npm run dev
   ```
6. Open the Vite URL printed in the terminal, usually `http://localhost:5173`. Register, log in, and try adding a resource.

## Troubleshooting

- **ECONNREFUSED / connect ECONNREFUSED 127.0.0.1:3306**: start MySQL in XAMPP; check its port (usually 3306).
- **Access denied for user 'root'**: enter your actual MySQL root password in `server/.env`.
- **Unknown database 'shareshelf'**: import `database/schema.sql` in phpMyAdmin.
- **Port 5000 already in use**: change `PORT` in `server/.env` and update `API` in `client/src/App.jsx` to match.
- If you change database tables, use the MySQL schema, not the original Oracle SQL.

Keep `server/.env` private. This project is configured for local development/demo use; change the JWT secret before any real deployment.

## Upgrade, demo data and testing

- Required `.env` values (unchanged): `PORT, DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME, JWT_SECRET`. No new variables.
- On every start the server upgrades the database automatically (adds `resources.access_level/file_*` and the `access_requests` table; deletes nothing). Look for `Database schema is up to date.` in the server terminal. If you see `DATABASE UPGRADE FAILED`, run `database/migration.sql` in phpMyAdmin and restart.
- API errors now include the real cause in brackets, e.g. `Could not save the resource. [ER_BAD_FIELD_ERROR: Unknown column ...]`.
- Demo data: `cd server && npm run seed` (insert-only, safe to repeat). Logins, password for both is `Demo@12345`:
  - `alice.demo@example.com`
  - `bob.demo@example.com`

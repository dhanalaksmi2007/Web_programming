import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/authRoutes.js';
import resourceRoutes from './routes/resourceRoutes.js';
import { checkDatabase, ensureSchema } from './db.js';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 5000);

app.use(cors({ origin: /^http:\/\/(localhost|127\.0\.0\.1):\d+$/ }));
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', (_req, res) => res.json({ status: 'ok', app: 'ShareShelf API' }));
app.use('/api/auth', authRoutes);
app.use('/api/resources', resourceRoutes);

app.use((err, _req, res, _next) => {
  console.error('Unhandled server error:', err.stack || err.message);
  res.status(500).json({ message: 'Unexpected server error.' });
});

app.listen(PORT, async () => {
  console.log(`ShareShelf API running at http://localhost:${PORT}`);
  try {
    await checkDatabase();
  } catch (error) {
    console.error('MySQL connection FAILED:', error.message);
    console.error('Check XAMPP MySQL is running and server/.env settings are correct.');
    return;
  }
  try {
    await ensureSchema();
  } catch (error) {
    console.error('DATABASE UPGRADE FAILED:', error.code || '', error.sqlMessage || error.message);
    console.error('Run database/migration.sql in phpMyAdmin (shareshelf database), then restart the server.');
  }
});

import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

let pool;
export async function getConnection() {
  if (!pool) {
    pool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      port: Number(process.env.DB_PORT || 3306),
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'shareshelf',
      waitForConnections: true,
      connectionLimit: 5,
      queueLimit: 0
    });
  }
  return pool.getConnection();
}
export async function checkDatabase() {
  const connection = await getConnection();
  try {
    const [rows] = await connection.query('SELECT 1 AS ok');
    console.log('MySQL connected successfully. Database test:', rows[0].ok);
  } finally { connection.release(); }
}

// Upgrades an existing ShareShelf database (adds new columns/table if missing). Safe to run on every start; never deletes data.
export async function ensureSchema() {
  const connection = await getConnection();
  try {
    const [cols] = await connection.query(
      "SELECT COLUMN_NAME AS col FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'resources'"
    );
    if (!cols.length) throw new Error("Table 'resources' not found in the selected database. Import database/schema.sql first.");
    const have = new Set(cols.map(c => String(c.col).toLowerCase()));
    const add = {
      access_level: "ENUM('public','request','private') NOT NULL DEFAULT 'public'",
      file_name: 'VARCHAR(255) NULL',
      file_stored_name: 'VARCHAR(100) NULL',
      file_mime: 'VARCHAR(100) NULL',
      file_size: 'INT UNSIGNED NULL'
    };
    for (const [name, def] of Object.entries(add)) {
      if (have.has(name)) continue;
      await connection.query(`ALTER TABLE resources ADD COLUMN ${name} ${def}`);
      console.log(`Migration: added resources.${name}`);
    }
    const tableSql = (withKeys) => `CREATE TABLE IF NOT EXISTS access_requests (
      id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      resource_id INT UNSIGNED NOT NULL,
      requester_id INT UNSIGNED NOT NULL,
      status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_request (resource_id, requester_id)${withKeys ? `,
      CONSTRAINT fk_req_resource FOREIGN KEY (resource_id) REFERENCES resources(id) ON DELETE CASCADE,
      CONSTRAINT fk_req_user FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE CASCADE` : ''}
    ) ENGINE=InnoDB`;
    try {
      await connection.query(tableSql(true));
    } catch (e) {
      // e.g. foreign-key type/engine mismatch in an older database: still create the table so the feature works.
      console.warn('access_requests with foreign keys failed (' + (e.sqlMessage || e.message) + '). Creating it without foreign keys.');
      await connection.query(tableSql(false));
    }
    // Verify every column the routes use really exists (throws with the exact SQL error if not).
    await connection.query('SELECT id, user_id, title, category, description, resource_url, availability, access_level, file_name, file_stored_name, file_mime, file_size, created_at FROM resources LIMIT 1');
    await connection.query('SELECT id, resource_id, requester_id, status, created_at, updated_at FROM access_requests LIMIT 1');
    console.log('Database schema is up to date.');
  } finally { connection.release(); }
}

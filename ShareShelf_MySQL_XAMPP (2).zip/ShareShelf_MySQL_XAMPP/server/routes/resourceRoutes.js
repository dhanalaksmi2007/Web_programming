import { Router } from 'express';
import multer from 'multer';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { getConnection } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

// ---- Upload config: files are stored OUTSIDE any static folder and are only served through the permission-checked route below.
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
const ALLOWED_TYPES = {
  '.pdf': 'application/pdf',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.txt': 'text/plain; charset=utf-8',
  '.doc': 'application/msword',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.ppt': 'application/vnd.ms-powerpoint',
  '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.xls': 'application/vnd.ms-excel',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
};
const INLINE_TYPES = new Set(['.pdf', '.png', '.jpg', '.jpeg']); // opened in browser; everything else downloads
const ACCESS_LEVELS = ['public', 'request', 'private'];

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex') + path.extname(file.originalname).toLowerCase())
});
const uploader = multer({
  storage,
  limits: { fileSize: MAX_FILE_SIZE, files: 1 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!ALLOWED_TYPES[ext]) return cb(new Error('FILE_TYPE'));
    cb(null, true);
  }
}).single('file');

function handleUpload(req, res, next) {
  uploader(req, res, (err) => {
    if (!err) return next();
    if (err.code === 'LIMIT_FILE_SIZE') return res.status(400).json({ message: 'File is too large. Maximum size is 10 MB.' });
    if (err.message === 'FILE_TYPE') return res.status(400).json({ message: 'Unsupported file type. Allowed: PDF, DOC/DOCX, PPT/PPTX, XLS/XLSX, TXT, PNG, JPG.' });
    console.error('Upload error:', err.message);
    return res.status(400).json({ message: 'File upload failed.' });
  });
}

function removeStoredFile(storedName) {
  if (!storedName || !/^[a-f0-9]{32}\.[a-z0-9]+$/.test(storedName)) return;
  fs.unlink(path.join(UPLOAD_DIR, storedName), () => {});
}

// Check the real file content (magic bytes) so a renamed .exe cannot pass as a .pdf.
function contentMatchesExtension(filePath, ext) {
  const fd = fs.openSync(filePath, 'r');
  const buf = Buffer.alloc(512);
  const n = fs.readSync(fd, buf, 0, 512, 0);
  fs.closeSync(fd);
  const head = buf.subarray(0, n);
  const starts = (...bytes) => bytes.every((b, i) => head[i] === b);
  switch (ext) {
    case '.pdf': return head.subarray(0, 1024).toString('latin1').includes('%PDF-');
    case '.png': return starts(0x89, 0x50, 0x4e, 0x47);
    case '.jpg': case '.jpeg': return starts(0xff, 0xd8, 0xff);
    case '.docx': case '.pptx': case '.xlsx': return starts(0x50, 0x4b);
    case '.doc': case '.ppt': case '.xls': return starts(0xd0, 0xcf, 0x11, 0xe0);
    case '.txt': return !head.includes(0);
    default: return false;
  }
}

function cleanUrl(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  let parsed;
  try { parsed = new URL(raw); } catch { return null; }
  if (!['http:', 'https:'].includes(parsed.protocol)) return null; // blocks javascript:, data:, etc.
  return raw;
}

async function loadResource(connection, id) {
  const [rows] = await connection.execute('SELECT * FROM resources WHERE id = ?', [Number(id)]);
  return rows[0] || null;
}

// Single place that decides who may open a resource's file / URL.
async function userCanAccess(connection, resource, userId) {
  if (resource.user_id === userId) return true;
  if (resource.access_level === 'public') return true;
  if (resource.access_level === 'private') return false;
  const [rows] = await connection.execute(
    "SELECT 1 FROM access_requests WHERE resource_id = ? AND requester_id = ? AND status = 'approved'",
    [resource.id, userId]
  );
  return rows.length > 0;
}

// Logs the real database/server error and (outside production) appends it to the message so the cause is visible.
function dbFail(res, label, userMessage, error) {
  console.error(`${label}:`, error.code || '', error.sqlMessage || error.message);
  if (res.headersSent) return;
  const detail = process.env.NODE_ENV === 'production' ? '' : ` [${error.code || 'ERROR'}: ${error.sqlMessage || error.message}]`;
  res.status(500).json({ message: userMessage + detail });
}

function searchTerm(req) { return `%${String(req.query.search || '').trim()}%`; }

// ---- My shelf
router.get('/', async (req, res) => {
  let connection;
  try {
    connection = await getConnection();
    const search = searchTerm(req);
    const [rows] = await connection.execute(
      `SELECT id, title, category, description, resource_url AS resourceUrl, availability, access_level AS accessLevel,
              file_name AS fileName, file_size AS fileSize, created_at AS createdAt
       FROM resources WHERE user_id = ? AND (title LIKE ? OR category LIKE ? OR description LIKE ?)
       ORDER BY created_at DESC`,
      [req.user.id, search, search, search]
    );
    res.json(rows.map(r => ({ ...r, hasFile: !!r.fileName })));
  } catch (error) { dbFail(res, 'Load resources error:', 'Could not load resources.', error); }
  finally { if (connection) connection.release(); }
});

// ---- Explore: resources of OTHER users that are public or request-only (private ones are never listed)
router.get('/explore', async (req, res) => {
  let connection;
  try {
    connection = await getConnection();
    const search = searchTerm(req);
    const [rows] = await connection.execute(
      `SELECT r.id, r.title, r.category, r.description, r.resource_url, r.availability, r.access_level, r.file_name, r.file_size,
              r.created_at, u.name AS ownerName, ar.status AS requestStatus
       FROM resources r
       JOIN users u ON u.id = r.user_id
       LEFT JOIN access_requests ar ON ar.resource_id = r.id AND ar.requester_id = ?
       WHERE r.user_id <> ? AND r.access_level IN ('public', 'request')
         AND (r.title LIKE ? OR r.category LIKE ? OR r.description LIKE ? OR u.name LIKE ?)
       ORDER BY r.created_at DESC`,
      [req.user.id, req.user.id, search, search, search, search]
    );
    res.json(rows.map(r => {
      const canAccess = r.access_level === 'public' || r.requestStatus === 'approved';
      return {
        id: r.id, title: r.title, category: r.category, description: r.description, availability: r.availability,
        accessLevel: r.access_level, ownerName: r.ownerName, createdAt: r.created_at,
        requestStatus: r.requestStatus || null,
        canAccess,
        hasFile: !!r.file_name,
        hasUrl: !!r.resource_url,
        // protected details are only sent to users who are allowed to see them
        resourceUrl: canAccess ? r.resource_url : null,
        fileName: canAccess ? r.file_name : null
      };
    }));
  } catch (error) { dbFail(res, 'Explore error:', 'Could not load shared resources.', error); }
  finally { if (connection) connection.release(); }
});

// ---- Owner: incoming access requests
router.get('/requests/incoming', async (req, res) => {
  let connection;
  try {
    connection = await getConnection();
    const [rows] = await connection.execute(
      `SELECT ar.id, ar.status, ar.created_at AS createdAt, r.id AS resourceId, r.title,
              u.name AS requesterName, u.email AS requesterEmail
       FROM access_requests ar
       JOIN resources r ON r.id = ar.resource_id
       JOIN users u ON u.id = ar.requester_id
       WHERE r.user_id = ?
       ORDER BY (ar.status = 'pending') DESC, ar.created_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (error) { dbFail(res, 'Incoming requests error:', 'Could not load access requests.', error); }
  finally { if (connection) connection.release(); }
});

router.patch('/requests/:requestId', async (req, res) => {
  let connection;
  try {
    const { status } = req.body;
    if (!['approved', 'rejected'].includes(status)) return res.status(400).json({ message: 'Status must be approved or rejected.' });
    connection = await getConnection();
    const [result] = await connection.execute(
      `UPDATE access_requests ar JOIN resources r ON r.id = ar.resource_id
       SET ar.status = ? WHERE ar.id = ? AND r.user_id = ?`,
      [status, Number(req.params.requestId), req.user.id]
    );
    if (!result.affectedRows) return res.status(404).json({ message: 'Request not found.' });
    res.json({ message: `Request ${status}.`, status });
  } catch (error) { dbFail(res, 'Update request error:', 'Could not update the request.', error); }
  finally { if (connection) connection.release(); }
});

// ---- Create (multipart/form-data; file is optional)
router.post('/', handleUpload, async (req, res) => {
  let connection;
  const storedName = req.file?.filename;
  try {
    const { title, category, description = '', resourceUrl = '', availability = 'Available', accessLevel = 'public' } = req.body;
    const allowed = ['Available', 'Borrowed', 'Digital'];
    const fail = (message) => { removeStoredFile(storedName); return res.status(400).json({ message }); };
    if (!title?.trim() || !category?.trim()) return fail('Title and category are required.');
    if (!allowed.includes(availability)) return fail('Please choose a valid availability option.');
    if (!ACCESS_LEVELS.includes(accessLevel)) return fail('Please choose a valid access option.');
    const url = cleanUrl(resourceUrl);
    if (url === null) return fail('Link must start with http:// or https://');
    if (req.file && !contentMatchesExtension(req.file.path, path.extname(req.file.originalname).toLowerCase())) {
      return fail('The file content does not match its type.');
    }
    connection = await getConnection();
    const originalName = req.file ? path.basename(req.file.originalname).slice(0, 255) : null;
    const [inserted] = await connection.execute(
      `INSERT INTO resources (user_id, title, category, description, resource_url, availability, access_level, file_name, file_stored_name, file_mime, file_size)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [req.user.id, title.trim(), category.trim(), description.trim(), url, availability, accessLevel,
        originalName, storedName || null, req.file ? ALLOWED_TYPES[path.extname(storedName)] : null, req.file ? req.file.size : null]
    );
    res.status(201).json({
      id: inserted.insertId, title: title.trim(), category: category.trim(), description: description.trim(),
      resourceUrl: url, availability, accessLevel, fileName: originalName, fileSize: req.file ? req.file.size : null, hasFile: !!req.file
    });
  } catch (error) {
    removeStoredFile(storedName);
    dbFail(res, 'Create resource error:', 'Could not save the resource.', error);
  } finally { if (connection) connection.release(); }
});

// ---- Owner: change access level
router.patch('/:id/access', async (req, res) => {
  let connection;
  try {
    const { accessLevel } = req.body;
    if (!ACCESS_LEVELS.includes(accessLevel)) return res.status(400).json({ message: 'Please choose a valid access option.' });
    connection = await getConnection();
    const [result] = await connection.execute('UPDATE resources SET access_level = ? WHERE id = ? AND user_id = ?', [accessLevel, Number(req.params.id), req.user.id]);
    if (!result.affectedRows) return res.status(404).json({ message: 'Resource not found.' });
    res.json({ message: 'Access updated.', accessLevel });
  } catch (error) { dbFail(res, 'Update access error:', 'Could not update access.', error); }
  finally { if (connection) connection.release(); }
});

// ---- Requester: ask for access
router.post('/:id/request', async (req, res) => {
  let connection;
  try {
    connection = await getConnection();
    const resource = await loadResource(connection, req.params.id);
    if (!resource || (resource.access_level === 'private' && resource.user_id !== req.user.id)) return res.status(404).json({ message: 'Resource not found.' });
    if (resource.user_id === req.user.id) return res.status(400).json({ message: 'This is your own resource.' });
    if (resource.access_level === 'public') return res.status(400).json({ message: 'This resource is already open to everyone.' });
    await connection.execute(
      `INSERT INTO access_requests (resource_id, requester_id, status) VALUES (?, ?, 'pending')
       ON DUPLICATE KEY UPDATE status = IF(status = 'rejected', 'pending', status)`,
      [resource.id, req.user.id]
    );
    const [rows] = await connection.execute('SELECT status FROM access_requests WHERE resource_id = ? AND requester_id = ?', [resource.id, req.user.id]);
    res.status(201).json({ message: 'Access request sent.', status: rows[0].status });
  } catch (error) { dbFail(res, 'Request access error:', 'Could not send the request.', error); }
  finally { if (connection) connection.release(); }
});

// ---- Open / download the uploaded file (permission enforced here, files are never served statically)
router.get('/:id/file', async (req, res) => {
  let connection;
  try {
    connection = await getConnection();
    const resource = await loadResource(connection, req.params.id);
    if (!resource || !resource.file_stored_name || (resource.access_level === 'private' && resource.user_id !== req.user.id)) {
      return res.status(404).json({ message: 'File not found.' });
    }
    if (!(await userCanAccess(connection, resource, req.user.id))) {
      return res.status(403).json({ message: 'You do not have access to this file. Request access from the owner.' });
    }
    const stored = resource.file_stored_name;
    if (!/^[a-f0-9]{32}\.[a-z0-9]+$/.test(stored)) return res.status(404).json({ message: 'File not found.' });
    const ext = path.extname(stored);
    const disposition = INLINE_TYPES.has(ext) && req.query.download !== '1' ? 'inline' : 'attachment';
    res.setHeader('Content-Type', ALLOWED_TYPES[ext] || 'application/octet-stream');
    res.setHeader('Content-Disposition', `${disposition}; filename*=UTF-8''${encodeURIComponent(resource.file_name || 'download' + ext)}`);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, no-store');
    res.sendFile(stored, { root: UPLOAD_DIR }, (err) => {
      if (err && !res.headersSent) res.status(404).json({ message: 'File not found.' });
    });
  } catch (error) { dbFail(res, 'File error:', 'Could not open the file.', error); }
  finally { if (connection) connection.release(); }
});

router.delete('/:id', async (req, res) => {
  let connection;
  try {
    connection = await getConnection();
    const [found] = await connection.execute('SELECT file_stored_name FROM resources WHERE id = ? AND user_id = ?', [Number(req.params.id), req.user.id]);
    const [result] = await connection.execute('DELETE FROM resources WHERE id = ? AND user_id = ?', [Number(req.params.id), req.user.id]);
    if (!result.affectedRows) return res.status(404).json({ message: 'Resource not found.' });
    removeStoredFile(found[0]?.file_stored_name);
    res.json({ message: 'Resource deleted successfully.' });
  } catch (error) { dbFail(res, 'Delete resource error:', 'Could not delete the resource.', error); }
  finally { if (connection) connection.release(); }
});
export default router;

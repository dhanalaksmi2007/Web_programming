import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { getConnection } from '../db.js';

const router = Router();
function makeToken(user) {
  return jwt.sign({ id: user.id, name: user.name, email: user.email }, process.env.JWT_SECRET || 'development_only_secret', { expiresIn: '2h' });
}
router.post('/register', async (req, res) => {
  let connection;
  try {
    const { name, email, password } = req.body;
    if (!name?.trim() || !email?.trim() || !password) return res.status(400).json({ message: 'Name, email, and password are required.' });
    if (password.length < 8) return res.status(400).json({ message: 'Password must contain at least 8 characters.' });
    const normalizedEmail = email.trim().toLowerCase();
    connection = await getConnection();
    const [existing] = await connection.execute('SELECT id FROM users WHERE email = ?', [normalizedEmail]);
    if (existing.length) return res.status(409).json({ message: 'An account with this email already exists.' });
    const passwordHash = await bcrypt.hash(password, 10);
    const [inserted] = await connection.execute(
      'INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)',
      [name.trim(), normalizedEmail, passwordHash]
    );
    const user = { id: inserted.insertId, name: name.trim(), email: normalizedEmail };
    return res.status(201).json({ message: 'Account created successfully.', token: makeToken(user), user });
  } catch (error) {
    console.error('Register error:', error.message);
    if (error.code === 'ER_DUP_ENTRY') return res.status(409).json({ message: 'An account with this email already exists.' });
    return res.status(500).json({ message: 'Could not create your account. Check the server and database.' });
  } finally { if (connection) connection.release(); }
});
router.post('/login', async (req, res) => {
  let connection;
  try {
    const { email, password } = req.body;
    if (!email?.trim() || !password) return res.status(400).json({ message: 'Email and password are required.' });
    connection = await getConnection();
    const [rows] = await connection.execute('SELECT id, name, email, password_hash FROM users WHERE email = ?', [email.trim().toLowerCase()]);
    const row = rows[0];
    if (!row || !(await bcrypt.compare(password, row.password_hash))) return res.status(401).json({ message: 'Incorrect email or password.' });
    const user = { id: row.id, name: row.name, email: row.email };
    return res.json({ message: 'Logged in successfully.', token: makeToken(user), user });
  } catch (error) {
    console.error('Login error:', error.message);
    return res.status(500).json({ message: 'Could not log in. Check the server and database.' });
  } finally { if (connection) connection.release(); }
});
export default router;

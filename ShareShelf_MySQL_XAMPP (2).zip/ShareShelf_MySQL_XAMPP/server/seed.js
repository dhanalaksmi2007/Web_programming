// Adds two demo accounts + sample resources. Insert-only: never updates or deletes anything. Safe to run repeatedly.
// Usage (from /server):  npm run seed
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { getConnection, ensureSchema } from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const PASSWORD = 'Demo@12345';

const users = [
  { name: 'Alice Demo', email: 'alice.demo@example.com' },
  { name: 'Bob Demo', email: 'bob.demo@example.com' }
];
const resources = [
  { owner: 'alice.demo@example.com', title: 'Demo: Algorithms Cheat Sheet (public)', category: 'Study Notes', availability: 'Digital', accessLevel: 'public',
    description: 'Public resource with an external link. Anyone logged in can open it.', url: 'https://en.wikipedia.org/wiki/Algorithm' },
  { owner: 'alice.demo@example.com', title: 'Demo: Alice Past Papers (request only)', category: 'Question Papers', availability: 'Digital', accessLevel: 'request',
    description: 'Protected file. Other users must request access; Alice approves or rejects.', file: { name: 'alice-past-papers.txt', text: 'ShareShelf demo file from Alice.\nYou can read this because you are the owner or were approved.\n' } },
  { owner: 'alice.demo@example.com', title: 'Demo: Alice Private Notes (private)', category: 'Other', availability: 'Available', accessLevel: 'private',
    description: 'Private: only Alice can see this. It must NOT appear in Bob\'s Explore list.' },
  { owner: 'bob.demo@example.com', title: 'Demo: Bob Study Guide (public)', category: 'Study Notes', availability: 'Digital', accessLevel: 'public',
    description: 'Public resource with an uploaded file.', file: { name: 'bob-study-guide.txt', text: 'ShareShelf demo file from Bob (public).\n' } },
  { owner: 'bob.demo@example.com', title: 'Demo: Bob Lab Manual (request only)', category: 'Books', availability: 'Digital', accessLevel: 'request',
    description: 'Protected file owned by Bob.', file: { name: 'bob-lab-manual.txt', text: 'ShareShelf demo file from Bob (protected).\n' } }
];
// requester email -> resource title -> status
const requests = [
  { requester: 'bob.demo@example.com', title: 'Demo: Alice Past Papers (request only)', status: 'pending' },
  { requester: 'alice.demo@example.com', title: 'Demo: Bob Lab Manual (request only)', status: 'approved' }
];

async function main() {
  await ensureSchema();
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  const connection = await getConnection();
  const ids = {};
  try {
    for (const u of users) {
      const [found] = await connection.execute('SELECT id FROM users WHERE email = ?', [u.email]);
      if (found.length) { ids[u.email] = found[0].id; console.log(`User exists, left unchanged: ${u.email}`); continue; }
      const [ins] = await connection.execute('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)', [u.name, u.email, await bcrypt.hash(PASSWORD, 10)]);
      ids[u.email] = ins.insertId;
      console.log(`User created: ${u.email}`);
    }
    const resourceIds = {};
    for (const r of resources) {
      const ownerId = ids[r.owner];
      const [found] = await connection.execute('SELECT id FROM resources WHERE user_id = ? AND title = ?', [ownerId, r.title]);
      if (found.length) { resourceIds[r.title] = found[0].id; console.log(`Resource exists, skipped: ${r.title}`); continue; }
      let stored = null, size = null;
      if (r.file) {
        stored = crypto.randomBytes(16).toString('hex') + '.txt';
        fs.writeFileSync(path.join(UPLOAD_DIR, stored), r.file.text);
        size = Buffer.byteLength(r.file.text);
      }
      const [ins] = await connection.execute(
        `INSERT INTO resources (user_id, title, category, description, resource_url, availability, access_level, file_name, file_stored_name, file_mime, file_size)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [ownerId, r.title, r.category, r.description, r.url || '', r.availability, r.accessLevel,
          r.file ? r.file.name : null, stored, r.file ? 'text/plain; charset=utf-8' : null, size]
      );
      resourceIds[r.title] = ins.insertId;
      console.log(`Resource created: ${r.title}`);
    }
    for (const q of requests) {
      await connection.execute('INSERT IGNORE INTO access_requests (resource_id, requester_id, status) VALUES (?, ?, ?)',
        [resourceIds[q.title], ids[q.requester], q.status]);
    }
    console.log('\nDone. Demo logins (password for both: ' + PASSWORD + '):');
    users.forEach(u => console.log(`  ${u.email}`));
  } finally { connection.release(); }
}
main().then(() => process.exit(0)).catch(e => { console.error('Seed failed:', e.code || '', e.sqlMessage || e.message); process.exit(1); });

import { useEffect, useMemo, useState } from 'react';
import {
  BookOpen, Search, Plus, LogOut, LibraryBig, Link as LinkIcon,
  Trash2, ExternalLink, GraduationCap, ShieldCheck, ArrowRight,
  Boxes, CheckCircle2, Sparkles, X, Compass, Inbox, Download, Lock, Check, FileText
} from 'lucide-react';

const API = 'http://localhost:5000/api';
const blankResource = { title: '', category: 'Study Notes', description: '', resourceUrl: '', availability: 'Available', accessLevel: 'public' };
const ACCESS_LABELS = { public: 'Public', request: 'Request only', private: 'Private' };
const INLINE_FILE = /\.(pdf|png|jpe?g)$/i;

async function apiRequest(path, options = {}, token = '') {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || 'Something went wrong.');
  return data;
}

function App() {
  const [token, setToken] = useState(() => localStorage.getItem('shareshelf_token') || '');
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('shareshelf_user') || 'null'); } catch { return null; }
  });
  const [mode, setMode] = useState('login');
  const [authForm, setAuthForm] = useState({ name: '', email: '', password: '' });
  const [resources, setResources] = useState([]);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [resourceForm, setResourceForm] = useState(blankResource);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [view, setView] = useState('shelf'); // 'shelf' | 'explore' | 'requests'
  const [resourceFile, setResourceFile] = useState(null);
  const [exploreResources, setExploreResources] = useState([]);
  const [exploreSearch, setExploreSearch] = useState('');
  const [requests, setRequests] = useState([]);

  const visibleResources = useMemo(() => {
    const query = search.toLowerCase().trim();
    if (!query) return resources;
    return resources.filter(r =>
      [r.title, r.category, r.description, r.availability].some(value => String(value || '').toLowerCase().includes(query))
    );
  }, [resources, search]);

  async function loadResources(currentToken = token) {
    if (!currentToken) return;
    try {
      const rows = await apiRequest('/resources', {}, currentToken);
      setResources(rows);
    } catch (e) {
      setError(e.message);
      if (e.message.toLowerCase().includes('session') || e.message.toLowerCase().includes('log in')) logout();
    }
  }

  useEffect(() => { if (token) loadResources(token); }, [token]);

  async function loadExplore() {
    try { setExploreResources(await apiRequest(`/resources/explore?search=${encodeURIComponent(exploreSearch.trim())}`, {}, token)); }
    catch (e) { setError(e.message); }
  }
  async function loadRequests() {
    try { setRequests(await apiRequest('/resources/requests/incoming', {}, token)); }
    catch (e) { setError(e.message); }
  }
  useEffect(() => {
    if (!token) return;
    if (view === 'explore') { const t = setTimeout(loadExplore, 250); return () => clearTimeout(t); }
    if (view === 'requests') loadRequests();
  }, [token, view, exploreSearch]);
  useEffect(() => { if (token) loadRequests(); }, [token]);

  // Files are fetched with the login token (backend checks permission), then opened/downloaded from a temporary blob URL.
  async function openFile(id, fileName, forceDownload = false) {
    setError('');
    const inline = !forceDownload && INLINE_FILE.test(fileName || '');
    const win = inline ? window.open('', '_blank') : null;
    try {
      const response = await fetch(`${API}/resources/${id}/file${inline ? '' : '?download=1'}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!response.ok) { const d = await response.json().catch(() => ({})); throw new Error(d.message || 'Could not open the file.'); }
      const blobUrl = URL.createObjectURL(await response.blob());
      if (win) { win.location.href = blobUrl; }
      else { const a = document.createElement('a'); a.href = blobUrl; a.download = fileName || 'download'; document.body.appendChild(a); a.click(); a.remove(); }
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
    } catch (e) { if (win) win.close(); setError(e.message); }
  }

  async function requestAccess(id) {
    setError(''); setMessage('');
    try { await apiRequest(`/resources/${id}/request`, { method: 'POST' }, token); setMessage('Access request sent to the owner.'); loadExplore(); }
    catch (e) { setError(e.message); }
  }
  async function decideRequest(requestId, status) {
    setError(''); setMessage('');
    try { await apiRequest(`/resources/requests/${requestId}`, { method: 'PATCH', body: JSON.stringify({ status }) }, token); setMessage(`Request ${status}.`); loadRequests(); }
    catch (e) { setError(e.message); }
  }
  async function changeAccess(id, accessLevel) {
    setError(''); setMessage('');
    try {
      await apiRequest(`/resources/${id}/access`, { method: 'PATCH', body: JSON.stringify({ accessLevel }) }, token);
      setResources(resources.map(r => r.id === id ? { ...r, accessLevel } : r));
      setMessage('Access updated.');
    } catch (e) { setError(e.message); }
  }

  function setAuthField(event) {
    setAuthForm({ ...authForm, [event.target.name]: event.target.value });
  }

  async function submitAuth(event) {
    event.preventDefault();
    setError(''); setMessage(''); setLoading(true);
    try {
      const data = await apiRequest(`/auth/${mode}`, {
        method: 'POST',
        body: JSON.stringify(authForm)
      });
      localStorage.setItem('shareshelf_token', data.token);
      localStorage.setItem('shareshelf_user', JSON.stringify(data.user));
      setToken(data.token); setUser(data.user);
      setMessage(mode === 'register' ? 'Your account is ready!' : 'Welcome back!');
      setAuthForm({ name: '', email: '', password: '' });
    } catch (e) {
      setError(e.message);
    } finally { setLoading(false); }
  }

  function logout() {
    localStorage.removeItem('shareshelf_token');
    localStorage.removeItem('shareshelf_user');
    setToken(''); setUser(null); setResources([]); setExploreResources([]); setRequests([]); setView('shelf');
    setMessage('You have logged out.');
    setError('');
  }

  async function submitResource(event) {
    event.preventDefault();
    setError(''); setMessage('');
    try {
      const body = new FormData();
      Object.entries(resourceForm).forEach(([key, value]) => body.append(key, value));
      if (resourceFile) body.append('file', resourceFile);
      const created = await apiRequest('/resources', { method: 'POST', body }, token);
      setResources([created, ...resources]);
      setResourceForm(blankResource);
      setResourceFile(null);
      setShowForm(false);
      setMessage('Resource added to your shelf.');
    } catch (e) { setError(e.message); }
  }

  async function deleteResource(id) {
    if (!window.confirm('Delete this resource from your shelf?')) return;
    setError(''); setMessage('');
    try {
      await apiRequest(`/resources/${id}`, { method: 'DELETE' }, token);
      setResources(resources.filter(item => item.id !== id));
      setMessage('Resource deleted.');
    } catch (e) { setError(e.message); }
  }

  const availableCount = resources.filter(r => r.availability === 'Available').length;
  const digitalCount = resources.filter(r => r.availability === 'Digital').length;
  const borrowedCount = resources.filter(r => r.availability === 'Borrowed').length;

  if (!token || !user) {
    return (
      <main className="auth-shell">
        <section className="auth-story">
          <div className="brand brand-light"><span className="brand-icon"><LibraryBig size={22} /></span><span>ShareShelf</span></div>
          <div className="story-copy">
            <span className="eyebrow"><Sparkles size={15} /> LEARN BETTER, TOGETHER</span>
            <h1>Good resources<br /><em>deserve to be shared.</em></h1>
            <p>Keep your study notes, helpful links, books and learning resources in one calm, organised space.</p>
            <div className="story-points">
              <div><span><BookOpen size={18} /></span><div><b>One organised shelf</b><small>Your useful resources, all together.</small></div></div>
              <div><span><ShieldCheck size={18} /></span><div><b>Your own account</b><small>Sign in to manage your collection.</small></div></div>
            </div>
          </div>
          <div className="story-footer">A little more sharing. A little less searching.</div>
        </section>
        <section className="auth-panel">
          <div className="mobile-brand brand"><span className="brand-icon"><LibraryBig size={22} /></span><span>ShareShelf</span></div>
          <div className="auth-card">
            <div className="auth-icon"><GraduationCap size={25} /></div>
            <p className="eyebrow">YOUR LEARNING SPACE</p>
            <h2>{mode === 'login' ? 'Welcome back' : 'Create your account'}</h2>
            <p className="muted">{mode === 'login' ? 'Sign in to open your personal shelf.' : 'Start collecting the things that help you learn.'}</p>
            {error && <div className="notice error">{error}</div>}
            {message && <div className="notice success">{message}</div>}
            <form onSubmit={submitAuth} className="form-stack">
              {mode === 'register' && <label>Full name<input name="name" value={authForm.name} onChange={setAuthField} placeholder="Your name" autoComplete="name" required /></label>}
              <label>Email address<input type="email" name="email" value={authForm.email} onChange={setAuthField} placeholder="you@example.com" autoComplete="email" required /></label>
              <label>Password<input type="password" name="password" value={authForm.password} onChange={setAuthField} placeholder="At least 8 characters" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} minLength={mode === 'register' ? 8 : undefined} required /></label>
              <button className="button primary full" type="submit" disabled={loading}>{loading ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'} <ArrowRight size={17} /></button>
            </form>
            <div className="auth-switch">{mode === 'login' ? "New to ShareShelf?" : 'Already have an account?'} <button onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); setMessage(''); }}>{mode === 'login' ? 'Create account' : 'Sign in'}</button></div>
            <div className="secure-note"><ShieldCheck size={15} /> Passwords are securely hashed before storage.</div>
          </div>
          <p className="copyright">© 2026 ShareShelf · Built for curious minds</p>
        </section>
      </main>
    );
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-icon"><LibraryBig size={22} /></span><span>ShareShelf</span></div>
        <div className="side-label">WORKSPACE</div>
        <button className={`nav-item ${view === 'shelf' ? 'active' : ''}`} onClick={() => setView('shelf')}><Boxes size={18} /> My shelf</button>
        <button className={`nav-item ${view === 'explore' ? 'active' : ''}`} onClick={() => setView('explore')}><Compass size={18} /> Explore Resources</button>
        <button className={`nav-item ${view === 'requests' ? 'active' : ''}`} onClick={() => setView('requests')}><Inbox size={18} /> Access requests{requests.some(r => r.status === 'pending') ? ` (${requests.filter(r => r.status === 'pending').length})` : ''}</button>
        <div className="side-tip"><span className="tip-icon"><Sparkles size={17} /></span><b>Share what helps.</b><p>Every useful note can make someone's next study session easier.</p></div>
        <div className="sidebar-bottom"><div className="avatar">{user.name?.charAt(0)?.toUpperCase() || 'U'}</div><div className="user-mini"><b>{user.name}</b><small>{user.email}</small></div><button className="icon-button" title="Log out" onClick={logout}><LogOut size={18} /></button></div>
      </aside>
      <main className="main-content">
        <header className="topbar"><div><p className="eyebrow">{view === 'shelf' ? 'YOUR PERSONAL LIBRARY' : view === 'explore' ? 'SHARED BY OTHERS' : 'PEOPLE WHO WANT ACCESS'}</p><h1>{view === 'shelf' ? 'My shelf' : view === 'explore' ? 'Explore Resources' : 'Access requests'} <span className="wave">✦</span></h1></div><button className="button primary" onClick={() => { setView('shelf'); setShowForm(true); setError(''); }}><Plus size={18} /> Add resource</button></header>
        {error && <div className="notice error global-notice"><span>{error}</span><button onClick={() => setError('')}><X size={16}/></button></div>}
        {message && <div className="notice success global-notice"><span>{message}</span><button onClick={() => setMessage('')}><X size={16}/></button></div>}
        {view === 'explore' && <section className="library-section">
          <div className="section-heading"><div><h2>Shared by other users</h2><p>Public resources, and ones you can request access to.</p></div><div className="search-box"><Search size={17}/><input value={exploreSearch} onChange={e => setExploreSearch(e.target.value)} placeholder="Search shared resources..." aria-label="Search shared resources"/></div></div>
          {exploreResources.length === 0 ? <div className="empty-state"><div className="empty-icon"><Compass size={27}/></div><h3>{exploreSearch ? 'No matching resources' : 'Nothing shared yet'}</h3><p>Resources shared by other users will appear here.</p></div> : <div className="resource-grid">{exploreResources.map(r => <article className="resource-card" key={r.id}>
            <div className="resource-card-top"><div className={`resource-icon icon-${iconTone(r.category)}`}>{r.hasFile ? <FileText size={21}/> : r.hasUrl ? <LinkIcon size={21}/> : <GraduationCap size={21}/>}</div><span className={`status-pill ${r.accessLevel === 'request' ? 'borrowed' : ''}`}>{r.accessLevel === 'request' ? <><Lock size={11}/> Request only</> : 'Public'}</span></div>
            <span className="category-label">{r.category}</span><h3>{r.title}</h3><small className="owner-line">Shared by {r.ownerName}</small>
            <p className="resource-description">{r.description || 'No description provided.'}</p>
            <div className="resource-card-bottom actions-col">
              {r.canAccess ? <div className="action-row">
                {r.hasFile && <button className="button secondary small" onClick={() => openFile(r.id, r.fileName)}>{INLINE_FILE.test(r.fileName || '') ? <><ExternalLink size={14}/> Open file</> : <><Download size={14}/> Download file</>}</button>}
                {r.resourceUrl && <a className="open-link" href={r.resourceUrl} target="_blank" rel="noreferrer">Open link <ExternalLink size={14}/></a>}
                {!r.hasFile && !r.resourceUrl && <small className="owner-line">No file or link attached.</small>}
              </div> : <div className="action-row">
                {r.requestStatus && <span className={`status-pill ${r.requestStatus}`}>{r.requestStatus === 'pending' ? 'Request pending' : r.requestStatus === 'rejected' ? 'Request rejected' : 'Approved'}</span>}
                {(!r.requestStatus || r.requestStatus === 'rejected') && <button className="button primary small" onClick={() => requestAccess(r.id)}><Lock size={14}/> {r.requestStatus === 'rejected' ? 'Request again' : 'Request Access'}</button>}
              </div>}
            </div>
          </article>)}</div>}
        </section>}
        {view === 'requests' && <section className="library-section">
          <div className="section-heading"><div><h2>Requests for your resources</h2><p>Approve or reject who can open your protected files.</p></div></div>
          {requests.length === 0 ? <div className="empty-state"><div className="empty-icon"><Inbox size={27}/></div><h3>No access requests</h3><p>Set a resource to "Request only" on your shelf to receive requests.</p></div> : <div className="request-list">{requests.map(q => <div className="request-row" key={q.id}>
            <div><b>{q.requesterName}</b> <small className="owner-line">({q.requesterEmail})</small><br/><small className="owner-line">wants access to "{q.title}"</small></div>
            <div className="action-row"><span className={`status-pill ${q.status}`}>{q.status.charAt(0).toUpperCase() + q.status.slice(1)}</span>
              {q.status !== 'approved' && <button className="button primary small" onClick={() => decideRequest(q.id, 'approved')}><Check size={14}/> Approve</button>}
              {q.status !== 'rejected' && <button className="button secondary small" onClick={() => decideRequest(q.id, 'rejected')}><X size={14}/> {q.status === 'approved' ? 'Revoke' : 'Reject'}</button>}
            </div>
          </div>)}</div>}
        </section>}
        {view === 'shelf' && <>
        <section className="welcome-banner"><div><span className="eyebrow">YOUR SHELF, YOUR WAY</span><h2>Hi {user.name?.split(' ')[0] || 'there'}, what are we learning today?</h2><p>Keep your favourite learning resources close at hand.</p></div><div className="banner-art"><div className="art-circle"><BookOpen size={37}/></div><span className="art-star star-one">✦</span><span className="art-star star-two">✧</span></div></section>
        <section className="stats-grid">
          <Stat icon={<LibraryBig size={20}/>} label="Total resources" count={resources.length} tone="purple" />
          <Stat icon={<CheckCircle2 size={20}/>} label="Available" count={availableCount} tone="green" />
          <Stat icon={<LinkIcon size={20}/>} label="Digital links" count={digitalCount} tone="blue" />
          <Stat icon={<BookOpen size={20}/>} label="Borrowed" count={borrowedCount} tone="orange" />
        </section>
        <section className="library-section">
          <div className="section-heading"><div><h2>Your collection</h2><p>Everything you've saved in one place.</p></div><div className="search-box"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search resources..." aria-label="Search resources"/></div></div>
          {showForm && <section className="resource-form-card"><div className="form-heading"><div><h3>Add a resource</h3><p>Save something useful for later.</p></div><button className="icon-button" onClick={() => setShowForm(false)} aria-label="Close form"><X size={19}/></button></div><form onSubmit={submitResource} className="resource-form">
            <label>Resource title *<input value={resourceForm.title} onChange={e => setResourceForm({...resourceForm, title:e.target.value})} placeholder="e.g. Data Structures Notes" required maxLength={180}/></label>
            <label>Category *<select value={resourceForm.category} onChange={e => setResourceForm({...resourceForm, category:e.target.value})}><option>Study Notes</option><option>Books</option><option>Video</option><option>Website</option><option>Question Papers</option><option>Tools</option><option>Other</option></select></label>
            <label className="wide">Description<textarea value={resourceForm.description} onChange={e => setResourceForm({...resourceForm, description:e.target.value})} placeholder="What makes this resource useful?" rows="3" maxLength={2000}/></label>
            <label className="wide">Resource link (optional)<input type="url" value={resourceForm.resourceUrl} onChange={e => setResourceForm({...resourceForm, resourceUrl:e.target.value})} placeholder="https://example.com"/></label>
            <label className="wide">Document (optional — PDF, DOC/DOCX, PPT/PPTX, XLS/XLSX, TXT, PNG, JPG · max 10 MB)<input type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.png,.jpg,.jpeg" onChange={e => { const f = e.target.files[0] || null; if (f && f.size > 10 * 1024 * 1024) { setError('File is too large. Maximum size is 10 MB.'); e.target.value = ''; setResourceFile(null); } else setResourceFile(f); }}/></label>
            <label>Who can access?<select value={resourceForm.accessLevel} onChange={e => setResourceForm({...resourceForm, accessLevel:e.target.value})}><option value="public">Public (all logged-in users)</option><option value="request">Private — others can request access</option><option value="private">Private — only me</option></select></label>
            <label>Availability<select value={resourceForm.availability} onChange={e => setResourceForm({...resourceForm, availability:e.target.value})}><option>Available</option><option>Borrowed</option><option>Digital</option></select></label>
            <div className="form-actions wide"><button type="button" className="button secondary" onClick={() => setShowForm(false)}>Cancel</button><button className="button primary" type="submit"><Plus size={17}/> Save resource</button></div>
          </form></section>}
          {visibleResources.length === 0 ? <div className="empty-state"><div className="empty-icon"><BookOpen size={27}/></div><h3>{search ? 'No matching resources' : 'Your shelf is ready for its first resource'}</h3><p>{search ? 'Try another search term.' : 'Add your first note, book or useful link to get started.'}</p>{!search && <button className="button primary" onClick={() => setShowForm(true)}><Plus size={17}/> Add first resource</button>}</div> : <div className="resource-grid">{visibleResources.map(resource => <article className="resource-card" key={resource.id}><div className="resource-card-top"><div className={`resource-icon icon-${iconTone(resource.category)}`}>{resource.category.toLowerCase().includes('book') ? <BookOpen size={21}/> : resource.resourceUrl ? <LinkIcon size={21}/> : <GraduationCap size={21}/>}</div><button className="icon-button delete-button" title="Delete resource" onClick={() => deleteResource(resource.id)}><Trash2 size={17}/></button></div><span className="category-label">{resource.category}</span><h3>{resource.title}</h3><p className="resource-description">{resource.description || 'A useful resource saved to your personal shelf.'}</p><div className="resource-card-bottom actions-col"><div className="action-row"><span className={`status-pill ${resource.availability.toLowerCase()}`}>{resource.availability}</span>{resource.hasFile && <button className="button secondary small" onClick={() => openFile(resource.id, resource.fileName)}>{INLINE_FILE.test(resource.fileName || '') ? <><ExternalLink size={14}/> Open file</> : <><Download size={14}/> Download file</>}</button>}{resource.resourceUrl && <a className="open-link" href={resource.resourceUrl} target="_blank" rel="noreferrer">Open link <ExternalLink size={14}/></a>}</div>{resource.fileName && <small className="owner-line">📎 {resource.fileName}</small>}<select className="access-select" value={resource.accessLevel} onChange={e => changeAccess(resource.id, e.target.value)} aria-label="Access setting"><option value="public">Public</option><option value="request">Private — requests allowed</option><option value="private">Private — only me</option></select></div></article>)}</div>}
        </section>
        </>}
        <footer className="page-footer">Made with care for better learning <span>✦</span></footer>
      </main>
    </div>
  );
}

function Stat({ icon, label, count, tone }) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div><p>{label}</p><strong>{count}</strong></div></div>;
}

function iconTone(category) {
  const value = category.toLowerCase();
  if (value.includes('book')) return 'orange';
  if (value.includes('video') || value.includes('website')) return 'blue';
  if (value.includes('question')) return 'green';
  return 'purple';
}

export default App;

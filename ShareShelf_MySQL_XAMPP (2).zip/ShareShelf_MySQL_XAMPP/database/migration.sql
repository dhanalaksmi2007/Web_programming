-- ShareShelf migration for an EXISTING database (XAMPP = MariaDB). Safe to run more than once; deletes nothing.
-- NOT required if the server prints "Database schema is up to date." (it runs this automatically on start).
-- phpMyAdmin: select the `shareshelf` database -> SQL tab -> paste -> Go.
USE shareshelf;

ALTER TABLE resources
  ADD COLUMN IF NOT EXISTS access_level ENUM('public','request','private') NOT NULL DEFAULT 'public',
  ADD COLUMN IF NOT EXISTS file_name VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS file_stored_name VARCHAR(100) NULL,
  ADD COLUMN IF NOT EXISTS file_mime VARCHAR(100) NULL,
  ADD COLUMN IF NOT EXISTS file_size INT UNSIGNED NULL;

CREATE TABLE IF NOT EXISTS access_requests (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  resource_id INT UNSIGNED NOT NULL,
  requester_id INT UNSIGNED NOT NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_request (resource_id, requester_id)
) ENGINE=InnoDB;

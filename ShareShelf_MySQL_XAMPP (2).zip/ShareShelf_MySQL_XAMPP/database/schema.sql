-- ShareShelf MySQL schema (XAMPP/phpMyAdmin)
CREATE DATABASE IF NOT EXISTS shareshelf CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE shareshelf;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS resources (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(180) NOT NULL,
  category VARCHAR(80) NOT NULL,
  description VARCHAR(2000),
  resource_url VARCHAR(2048),
  availability ENUM('Available', 'Borrowed', 'Digital') NOT NULL DEFAULT 'Available',
  access_level ENUM('public', 'request', 'private') NOT NULL DEFAULT 'public',
  file_name VARCHAR(255) NULL,
  file_stored_name VARCHAR(100) NULL,
  file_mime VARCHAR(100) NULL,
  file_size INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_resources_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_resources_title (title),
  INDEX idx_resources_category (category)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS access_requests (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  resource_id INT UNSIGNED NOT NULL,
  requester_id INT UNSIGNED NOT NULL,
  status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_request (resource_id, requester_id),
  CONSTRAINT fk_req_resource FOREIGN KEY (resource_id) REFERENCES resources(id) ON DELETE CASCADE,
  CONSTRAINT fk_req_user FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
